function doSomething() {
    $.get("./registros/facebook.php");
    return false;
}