<?php
include 'db.php';
session_start();

#Valida si existe la sesion
if (!isset($_SESSION['id_user'])) {
    header("Location: index.php");
}
?>
<!doctype html>
<html lang="es">
  <head>
    <title></title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://unpkg.com/ionicons@4.5.10-0/dist/css/ionicons.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="images/G.png" />
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="libs/sweetalert2.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  </head>
  <body class="scrol">
  <div class="d-flex">
        <div class="bg-primary" id="sidebar-container" style="background-color: #111B54">
            <div class="logo">
                <br>
                <br>
                <br>
                <br>
                <h3 class="text-light font-weight-bold">Panel de Administraci&oacute;n</h3>
            </div>
            <div class="menu">
              
                <a href="cotizacion.php" style="text-decoration: none; font-size: 19px;" class="text-light d-block p-4"><i class="icon ion-md-list mr-4 lead"></i>&nbsp;&nbsp;Cotización</a>
                <a href="logout.php" style="text-decoration: none; font-size: 19px;" class="text-light d-block p-4" href="logout.php"><i class="icon ion-md-exit mr-4 lead"></i>&nbsp;&nbsp;Cerrar Sesión</a>

            </div>
        </div>
                <div class="w-100">
            <div class="jumbotron-fluid" style="background-color: #F4F6F7" align="right">
                &nbsp;

                &nbsp;&nbsp;
            </div>
                              <div class="w-100" style="display: flex; justify-content: space-between; background-color: #F4F6F7; padding: 0 20px;">
                        <div style="align-self: center;">
                            <h3 style="color: #111B54; font-size: 50px; font-weight: 700;">
                                Cotizaciones
                            </h3>
                        </div>
                        <div style="align-self: center;">
                            <h3 style="color: #111B54; font-size: 50px; font-weight: 700;">
                                Ventas
                            </h3>
                        </div>
                    </div>
            <br>
     