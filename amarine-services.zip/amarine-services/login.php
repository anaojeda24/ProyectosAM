<?php
session_start();

$users = [
    'admin' => 'password123',
    'Pedro' => 'p123',
    'Francisco' => 'f123'
];

if(!empty($_POST)){
    $username = $_POST['txtCorreo']; 
    $password = $_POST['txtContrasenia'];

    if (array_key_exists($username, $users) && $users[$username] === $password) {
        $_SESSION['id_user'] = 1;
        header('location: cotizacion.php');
    } else {
        $_SESSION['error_message'] = 'Usuario o contraseña incorrectos';
        header('Location: index.php?status=1');
    }
}
?>