<?php
include 'header.php';
include 'db.php';
?>

<div class="container-fluid">
    <br>

    <h3 style="color: #111B54; font-size: 40px; font-weight: 400;">
        Servicios técnicos
    </h3>
  
    <br>
 

    <div class="d-flex">
       <div class="card" style="flex: 1; margin-right: 10px;">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12" style="color: #111B54; font-size: 25px; font-weight: 500;">
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Fecha de solicitud:</strong></label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" id="fechaSolicitud" placeholder="Fecha de Vigencia">
                        </div>
                    </div>
                                        <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Número de proyecto</strong></label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" id="numeroProyecto" placeholder="Número de proyecto">
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Tipo de servicio:</strong></label>
                        <div class="col-sm-8">
                            <select class="form-control custom-select" id="tipoServicio">
                                <option disabled selected>Seleccione un servicio</option>
                                <option>Mantenimiento</option>
                                <option>Arrendamiento</option>
                                <option>Capacitación</option>
                                <option>Sistemas integrales</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Especificaciones técnicas:</strong></label>
                        <div class="col-sm-8">
                            <select class="form-control custom-select" id="especificacionesTecnicas">
                                <option disabled selected>Seleccione un servicio</option>
                                <option>Mantto. Extintores</option>
                                <option>Arrendamiento SCBA</option>
                                <option>Capacitación H2S</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Claves:</strong></label>
                        <div class="col-sm-8">
                            <select class="form-control custom-select" id="claves">
                                <option disabled selected>Seleccione una clave</option>
                                <option>SR-M01</option>
                                <option>SR-A01</option>
                                <option>SR-C01</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Almacén:</strong></label>
                        <div class="col-sm-8">
                            <select class="form-control custom-select" id="almacen" placeholder="Seleccione un almacén">
                                <option disabled selected>Seleccione un almacén</option>
                                <option>Villahermosa</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Fecha requerida:</strong></label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" id="fechaRequerida" placeholder="Fecha de Solicitud">
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Fecha de Vigencia:</strong></label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" id="fechaVigencia" placeholder="Fecha de Vigencia">
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Cantidad</strong></label>
                        <div class="col-sm-8">
                            <input type="number" class="form-control" id="cantidad" placeholder="Cantidad">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card" style="flex: 1; margin-left: 10px;">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12" style="color: #111B54; font-size: 25px; font-weight: 500;">
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Cliente:</strong></label>
                        <div class="col-sm-8">
                            <select class="form-control custom-select" id="cliente">
                                <option disabled selected>Seleccione un cliente</option>
                                <option>Fielwood energy E&P</option>
                                <option>Geolis</option>
                                <option>GSM-BRONCO</option>
                                <option>Mazda</option>
                                <option>OLAM Energy</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Precio</strong></label>
                        <div class="col-sm-8">
                            <input type="number" class="form-control" id="precio" placeholder="Precio $">
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Moneda</strong></label>
                        <div class="col-sm-8">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="moneda" id="monedaMXN" value="MXN">
                                <label class="form-check-label" for="monedaMXN">
                                    MXN
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="moneda" id="monedaUSD" value="USD">
                                <label class="form-check-label" for="monedaUSD">
                                    USD
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Vendedor:</strong></label>
                        <div class="col-sm-8">
                            <select class="form-control custom-select" id="vendedor" placeholder="Seleccione un proyecto">
                                <option disabled selected>Seleccione un vendedor</option>
                                <option>Pedro Cadena</option>
                                <option>Raúl Lozano</option>
                                <option>Francisco Gallegos</option>
                                <option>Arturo Medina</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label class="col-sm-4 col-form-label"><strong>Observación:</strong></label>
                        <div class="col-sm-8">
                            <textarea class="form-control resizable" id="observacion" placeholder="Observación"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
       <div class="text-center my-4">
        <button type="button" class="btn btn-success btn-lg" id="registrarBtn">Registrar</button>
    </div>
    
 <!-- Tabla para mostrar los datos registrados -->
<div class="container mt-4" id="tablaContainer" style="display: none;">
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-hover table-white table-custom">
            <thead class="thead-dark">
                <tr>
                    <th>Fecha de Solicitud</th>
                    <th>Número de Proyecto</th>
                    <th>Tipo de Servicio</th>
                    <th>Especificaciones Técnicas</th>
                    <th>Claves</th>
                    <th>Almacén</th>
                    <th>Fecha Requerida</th>
                    <th>Fecha de Vigencia</th>
                    <th>Cantidad</th>
                    <th>Cliente</th>
                    <th>Precio</th>
                    <th>Moneda</th>
                    <th>Vendedor</th>
                    <th>Observación</th>
                </tr>
            </thead>
            <tbody id="datosRegistrados">
                <!-- Las filas se agregarán aquí -->
            </tbody>
        </table>
    </div>
</div>
    
<style>
    .btn-lg {
        padding: 15px 30px;
        font-size: 1.25rem;
    }

    .table-custom {
        border-radius: 10px;
        overflow: hidden;
        font-family: 'Rockwell', serif;
        width: 100%; 
    }
    .table-custom th, .table-custom td {
        border: 1px solid #ddd;
    }
    .table-custom thead {
        background-color: #111b54;
        color: white;
    }
    .table-custom tbody tr:hover {
        background-color: #f1f1f1;
    }

    /* Media query para pantallas más grandes */
    @media (min-width: 992px) {
        .table-responsive {
            overflow-x: visible;
        }
    }
</style>
    
    <script>
        document.getElementById('registrarBtn').addEventListener('click', function() {
            document.getElementById('tablaContainer').style.display = 'block';
        });
    </script>

    <script>
        document.getElementById('registrarBtn').addEventListener('click', function () {
            // esta mamada guarda los datos en variables
            var fechaSolicitud = document.getElementById('fechaSolicitud').value;
            var numeroProyecto = document.getElementById('numeroProyecto').value;
            var tipoServicio = document.getElementById('tipoServicio').value;
            var especificacionesTecnicas = document.getElementById('especificacionesTecnicas').value;
            var claves = document.getElementById('claves').value;
            var almacen = document.getElementById('almacen').value;
            var fechaRequerida = document.getElementById('fechaRequerida').value;
            var fechaVigencia = document.getElementById('fechaVigencia').value;
            var cantidad = document.getElementById('cantidad').value;
            var cliente = document.getElementById('cliente').value;
            var precio = document.getElementById('precio').value;
            var moneda = document.querySelector('input[name="moneda"]:checked').value;
            var vendedor = document.getElementById('vendedor').value;
            var observacion = document.getElementById('observacion').value;

            //Con esto mando a llamar el sweet alert2 para mostrar los datos
            Swal.fire({
                title: 'Datos Guardados',
                html: '<p><strong>Fecha de Solicitud:</strong> ' + fechaSolicitud + '</p>' +
                      '<p><strong>Número de Proyecto:</strong> ' + numeroProyecto + '</p>' +
                      '<p><strong>Tipo de Servicio:</strong> ' + tipoServicio + '</p>' +
                      '<p><strong>Especificaciones Técnicas:</strong> ' + especificacionesTecnicas + '</p>' +
                      '<p><strong>Claves:</strong> ' + claves + '</p>' +
                      '<p><strong>Almacén:</strong> ' + almacen + '</p>' +
                      '<p><strong>Fecha Requerida:</strong> ' + fechaRequerida + '</p>' +
                      '<p><strong>Fecha de Vigencia:</strong> ' + fechaVigencia + '</p>' +
                      '<p><strong>Cantidad:</strong> ' + cantidad + '</p>' +
                      '<p><strong>Cliente:</strong> ' + cliente + '</p>' +
                      '<p><strong>Precio:</strong> ' + precio + '</p>' +
                      '<p><strong>Moneda:</strong> ' + moneda + '</p>' +
                      '<p><strong>Vendedor:</strong> ' + vendedor + '</p>' +
                      '<p><strong>Observación:</strong> ' + observacion + '</p>',
                icon: 'success',
                confirmButtonText: 'Aceptar'
            });
     
        // Agregar los datos a la tabla
        var tabla = document.getElementById('datosRegistrados');
            var nuevaFila = tabla.insertRow();

            nuevaFila.insertCell(0).innerText = fechaSolicitud;
            nuevaFila.insertCell(1).innerText = numeroProyecto;
            nuevaFila.insertCell(2).innerText = tipoServicio;
            nuevaFila.insertCell(3).innerText = especificacionesTecnicas;
            nuevaFila.insertCell(4).innerText = claves;
            nuevaFila.insertCell(5).innerText = almacen;
            nuevaFila.insertCell(6).innerText = fechaRequerida;
            nuevaFila.insertCell(7).innerText = fechaVigencia;
            nuevaFila.insertCell(8).innerText = cantidad;
            nuevaFila.insertCell(9).innerText = cliente;
            nuevaFila.insertCell(10).innerText = precio;
            nuevaFila.insertCell(11).innerText = moneda;
            nuevaFila.insertCell(12).innerText = vendedor;
            nuevaFila.insertCell(13).innerText = observacion;
        });
    </script>


</div>

<style>
    .custom-select {
        position: relative;
        appearance: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        background: url('data:image/svg+xml;utf8,<svg fill="none" stroke="%23111B54" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M19 9l-7 7-7-7"></path></svg>') no-repeat right 10px center;
        background-size: 16px 16px;
        padding-right: 30px;
    }

    .resizable {
        resize: both;
        overflow: auto;
    }
</style>

<?php
include 'footer.php';
?>